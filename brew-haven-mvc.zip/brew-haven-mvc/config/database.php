<?php
class Database {
    private static $host = "localhost";
    private static $db_name = "brew_haven_db";
    private static $username = "root"; // Cambiar en producción (Hosting)
    private static $password = "";     // Cambiar en producción (Hosting)

    public static function connect() {
        try {
            $pdo = new PDO(
                "mysql:host=" . self::$host . ";dbname=" . self::$db_name . ";charset=utf8mb4",
                self::$username,
                self::$password
            );
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $pdo;
        } catch (PDOException $e) {
            die("Error de conexión a la base de datos: " . $e->getMessage());
        }
    }
}