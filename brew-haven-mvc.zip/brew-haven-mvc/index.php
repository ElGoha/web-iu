<?php
require_once 'controllers/HomeController.php';
require_once 'controllers/PedidoController.php';

$action = $_GET['action'] ?? 'index';

$homeController = new HomeController();
$pedidoController = new PedidoController();

switch ($action) {
    case 'crud':
        // Carga el formulario CRUD y lista de pedidos (GET para editar o eliminar)
        $pedidoController->index();
        break;
    case 'guardar':
        // Procesa creación o actualización vía POST
        $pedidoController->guardar();
        break;
    case 'eliminar':
        // Procesa eliminación vía GET
        $pedidoController->eliminar();
        break;
    case 'gracias':
        // Muestra la página de confirmación tras enviar el formulario
        $pedidoController->gracias();
        break;
    default:
        // Página principal con las 7+ secciones
        $homeController->index();
        break;
}