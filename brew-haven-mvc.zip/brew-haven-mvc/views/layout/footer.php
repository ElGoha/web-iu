<!-- SECCIÓN 8: FOOTER -->
<footer class="pt-5 pb-4 bg-coffee-darker border-top border-secondary border-opacity-25 mt-5">
    <div class="container">
        <div class="row g-4 mb-4">
            <div class="col-lg-4">
                <h4 class="font-serif text-gold fw-bold mb-3"><i class="fas fa-mug-hot me-2"></i>BREW HAVEN</h4>
                <p class="text-secondary-coffee small">
                    Handcrafted specialty coffee roasted with passion. Follow us on social media for daily coffee inspiration.
                </p>
                <div class="d-flex gap-3 fs-5">
                    <a href="#" class="text-light hover-link"><i class="fab fa-facebook"></i></a>
                    <a href="#" class="text-light hover-link"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="text-light hover-link"><i class="fab fa-twitter"></i></a>
                </div>
            </div>
            <div class="col-6 col-lg-2">
                <h6 class="fw-bold text-white mb-3">Quick Links</h6>
                <ul class="list-unstyled small text-secondary-coffee d-grid gap-2">
                    <li><a href="index.php#inicio" class="text-decoration-none text-reset hover-link">Home</a></li>
                    <li><a href="index.php#menu" class="text-decoration-none text-reset hover-link">Menu</a></li>
                    <li><a href="index.php#nosotros" class="text-decoration-none text-reset hover-link">About Us</a></li>
                    <li><a href="index.php?action=crud" class="text-decoration-none text-reset hover-link">Pedidos</a></li>
                </ul>
            </div>
            <div class="col-6 col-lg-3">
                <h6 class="fw-bold text-white mb-3">Customer Care</h6>
                <ul class="list-unstyled small text-secondary-coffee d-grid gap-2">
                    <li>FAQs</li>
                    <li>Shipping & Delivery</li>
                    <li>Terms & Conditions</li>
                    <li>Privacy Policy</li>
                </ul>
            </div>
            <div class="col-lg-3">
                <h6 class="fw-bold text-white mb-3">Contact Us</h6>
                <ul class="list-unstyled small text-secondary-coffee d-grid gap-2">
                    <li><i class="fas fa-phone text-gold me-2"></i> +57 300 123 4567</li>
                    <li><i class="fas fa-envelope text-gold me-2"></i> hello@brewhaven.com</li>
                    <li><i class="fas fa-map-marker-alt text-gold me-2"></i> 123 Coffee Lane, Brew City</li>
                </ul>
            </div>
        </div>
        <div class="text-center text-secondary-coffee small pt-3 border-top border-secondary border-opacity-10">
            &copy; <?= date('Y') ?> Brew Haven Coffee Co. Todos los derechos reservados.
        </div>
    </div>
</footer>

<!-- REQUISITO 9: BOTÓN FLOTANTE DE WHATSAPP -->
<a href="https://wa.me/573001234567?text=Hola%20Brew%20Haven,%20quisiera%20hacer%20un%20pedido" 
   class="whatsapp-float anim-pulse" 
   target="_blank" 
   aria-label="Chatear por WhatsApp">
    <i class="fab fa-whatsapp"></i>
</a>

<!-- Scripts: Bootstrap, Swiper, AOS y JS propio -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>