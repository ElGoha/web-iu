<?php include 'views/layout/header.php'; ?>

<section class="py-5 my-5 text-center">
    <div class="container py-5" data-aos="zoom-in">
        <div class="card-coffee p-5 rounded-4 mx-auto" style="max-width: 600px;">
            <div class="display-1 text-gold mb-3 anim-pulse">
                <i class="fas fa-check-circle"></i>
            </div>
            <h1 class="font-serif fw-bold mb-3">¡Muchas Gracias, <?= htmlspecialchars($cliente) ?>!</h1>
            <p class="text-secondary-coffee fs-5 mb-4">
                Tu registro ha sido <strong><?= htmlspecialchars($tipo) ?></strong> correctamente en nuestro sistema. Nuestro equipo de baristas ya está preparando tu experiencia Brew Haven.
            </p>
            <div class="d-flex justify-content-center gap-3">
                <a href="index.php" class="btn btn-gold px-4 py-2 rounded-pill hover-btn">Volver al Inicio</a>
                <a href="index.php?action=crud" class="btn btn-outline-light px-4 py-2 rounded-pill hover-btn">Ver Mis Pedidos</a>
            </div>
        </div>
    </div>
</section>

<?php include 'views/layout/footer.php'; ?>