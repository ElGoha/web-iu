<?php include 'views/layout/header.php'; ?>

<!-- SECCIÓN 2: HERO SECTION (Con Imagen Relativa #1) -->
<section id="inicio" class="py-5 hero-section">
    <div class="container py-lg-4">
        <div class="row align-items-center g-5">
            <div class="col-lg-6" data-aos="fade-right">
                <p class="font-serif fst-italic text-gold fs-5 mb-2">Rich. Smooth. Perfect.</p>
                <h1 class="display-3 font-serif fw-bold mb-3">Experience Coffee Like Never Before</h1>
                <p class="text-secondary-coffee mb-4 fs-5">
                    Handcrafted coffee made from the finest beans, brewed to perfection for you.
                </p>
                <div class="d-flex flex-wrap gap-3 mb-5">
                    <a href="#menu" class="btn btn-gold px-4 py-2 rounded-pill hover-btn">
                        Explore Menu <i class="fas fa-arrow-right ms-2"></i>
                    </a>
                    <a href="#nosotros" class="btn btn-outline-light px-4 py-2 rounded-pill hover-btn">
                        Our Story <i class="far fa-play-circle ms-2"></i>
                    </a>
                </div>
                <div class="row g-3 text-center text-sm-start">
                    <div class="col-4">
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge-icon"><i class="fas fa-seedling text-gold"></i></span>
                            <small class="lh-sm">Premium<br>Quality Beans</small>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge-icon"><i class="fas fa-fire text-gold"></i></span>
                            <small class="lh-sm">Expertly<br>Roasted</small>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge-icon"><i class="fas fa-heart text-gold"></i></span>
                            <small class="lh-sm">Made With<br>Love</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 text-center" data-aos="zoom-in">
                <!-- IMAGEN 1 CON RUTA RELATIVA -->
                <div class="hero-img-wrapper">
                    <img src="assets/img/hero-coffee.jpg" alt="Taza de café humeante" class="img-fluid rounded-4 shadow-lg anim-float">
                </div>
            </div>
        </div>
    </div>
</section>

<!-- SECCIÓN 3: ABOUT US (Con Imagen Relativa #2) -->
<section id="nosotros" class="py-5 bg-coffee-medium">
    <div class="container py-4">
        <div class="row align-items-center g-5">
            <div class="col-lg-6" data-aos="fade-up">
                <!-- IMAGEN 2 CON RUTA RELATIVA -->
                <img src="assets/img/about-bag.jpg" alt="Empaque Brew Haven Coffee Co." class="img-fluid rounded-4 shadow hover-zoom">
            </div>
            <div class="col-lg-6" data-aos="fade-left">
                <span class="font-serif fst-italic text-gold fs-5">About Us</span>
                <h2 class="display-5 font-serif fw-bold mt-1 mb-3">More Than Just a Coffee</h2>
                <p class="text-secondary-coffee mb-4">
                    At Brew Haven, we believe coffee is more than a drink – it's an experience. Every cup we serve is a blend of passion, quality, and perfection.
                </p>
                <ul class="list-unstyled d-grid gap-3 mb-4">
                    <li><i class="fas fa-leaf text-gold me-2"></i> Sustainably Sourced Beans</li>
                    <li><i class="fas fa-handshake text-gold me-2"></i> Ethically Traded</li>
                    <li><i class="fas fa-mug-hot text-gold me-2"></i> Freshly Roasted</li>
                    <li><i class="fas fa-award text-gold me-2"></i> Barista Crafted</li>
                </ul>
                <a href="index.php?action=crud" class="btn btn-gold px-4 py-2 rounded-pill hover-btn">
                    Hacer un Pedido <i class="fas fa-arrow-right ms-2"></i>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- SECCIÓN 4: POPULAR PICKS (Carrusel Swiper.js + Datos desde MySQL + Imágenes Absolutas) -->
<section id="menu" class="py-5">
    <div class="container py-4">
        <div class="text-center mb-5" data-aos="fade-up">
            <span class="font-serif fst-italic text-gold fs-5">Our Signature</span>
            <h2 class="display-5 font-serif fw-bold">Popular Picks</h2>
        </div>

        <!-- Carrusel con librería Swiper.js -->
        <div class="swiper mySwiper pb-5" data-aos="fade-up">
            <div class="swiper-wrapper">
                <?php foreach ($productos as $prod): ?>
                <div class="swiper-slide">
                    <div class="card card-coffee h-100 border-0 rounded-4 overflow-hidden hover-card">
                        <!-- IMÁGENES CON RUTA ABSOLUTA DESDE LA BASE DE DATOS -->
                        <img src="<?= htmlspecialchars($prod['imagen_url']) ?>" 
                             class="card-img-top object-fit-cover" 
                             style="height: 230px;" 
                             alt="<?= htmlspecialchars($prod['nombre']) ?>">
                        <div class="card-body d-flex flex-column justify-content-between p-4">
                            <div>
                                <span class="badge bg-dark text-gold mb-2"><?= htmlspecialchars($prod['categoria_nombre']) ?></span>
                                <h5 class="card-title font-serif fw-bold text-white"><?= htmlspecialchars($prod['nombre']) ?></h5>
                                <p class="card-text text-secondary-coffee small"><?= htmlspecialchars($prod['descripcion']) ?></p>
                            </div>
                            <div class="d-flex justify-content-between align-items-center mt-3 pt-2 border-top border-secondary border-opacity-25">
                                <span class="fs-5 fw-bold text-white">$<?= number_format($prod['precio'], 2) ?></span>
                                <a href="index.php?action=crud&producto_id=<?= $prod['id'] ?>" class="btn btn-sm btn-gold rounded-3 hover-btn" title="Ordenar ahora">
                                    <i class="fas fa-shopping-bag"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-next text-gold"></div>
            <div class="swiper-button-prev text-gold"></div>
        </div>

        <div class="text-center mt-3">
            <a href="index.php?action=crud" class="btn btn-outline-light rounded-pill px-4 py-2 hover-btn">
                Ir al Formulario de Pedidos <i class="fas fa-arrow-right ms-2"></i>
            </a>
        </div>
    </div>
</section>

<!-- SECCIÓN 5: FRANJA DE BENEFICIOS (4 Columnas como en el diseño) -->
<section id="beneficios" class="py-4">
    <div class="container">
        <div class="benefits-box p-4 rounded-4" data-aos="zoom-in">
            <div class="row g-4 text-center text-md-start">
                <div class="col-6 col-lg-3 d-flex align-items-center gap-3 justify-content-center">
                    <i class="fas fa-truck fs-2 text-gold"></i>
                    <div>
                        <h6 class="mb-0 fw-bold">Free Delivery</h6>
                        <small class="text-secondary-coffee">On orders above $249</small>
                    </div>
                </div>
                <div class="col-6 col-lg-3 d-flex align-items-center gap-3 justify-content-center">
                    <i class="fas fa-stopwatch fs-2 text-gold"></i>
                    <div>
                        <h6 class="mb-0 fw-bold">Fresh & Fast</h6>
                        <small class="text-secondary-coffee">Prepared with care</small>
                    </div>
                </div>
                <div class="col-6 col-lg-3 d-flex align-items-center gap-3 justify-content-center">
                    <i class="fas fa-shield-alt fs-2 text-gold"></i>
                    <div>
                        <h6 class="mb-0 fw-bold">Secure Payment</h6>
                        <small class="text-secondary-coffee">100% safe & secure</small>
                    </div>
                </div>
                <div class="col-6 col-lg-3 d-flex align-items-center gap-3 justify-content-center">
                    <i class="fas fa-star fs-2 text-gold"></i>
                    <div>
                        <h6 class="mb-0 fw-bold">Loyalty Rewards</h6>
                        <small class="text-secondary-coffee">Earn points every order</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- SECCIÓN 6: TESTIMONIOS DE CLIENTES -->
<section id="testimonios" class="py-5 bg-coffee-medium">
    <div class="container py-4">
        <div class="text-center mb-5" data-aos="fade-up">
            <span class="font-serif fst-italic text-gold fs-5">Testimonials</span>
            <h2 class="display-6 font-serif fw-bold">What Coffee Lovers Say</h2>
        </div>
        <div class="row g-4">
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                <div class="card-coffee p-4 rounded-4 h-100 hover-card">
                    <div class="text-gold mb-2"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                    <p class="text-secondary-coffee fst-italic">"El Iced Caramel Latte tiene el balance exacto entre dulzor y el tostado intenso del grano."</p>
                    <h6 class="fw-bold mb-0">— Camila Torres</h6>
                </div>
            </div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
                <div class="card-coffee p-4 rounded-4 h-100 hover-card">
                    <div class="text-gold mb-2"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                    <p class="text-secondary-coffee fst-italic">"Ambiente acogedor, entrega rápida y el mejor espresso de la ciudad sin lugar a dudas."</p>
                    <h6 class="fw-bold mb-0">— Andrés Mendoza</h6>
                </div>
            </div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="300">
                <div class="card-coffee p-4 rounded-4 h-100 hover-card">
                    <div class="text-gold mb-2"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                    <p class="text-secondary-coffee fst-italic">"Compro sus bolsas de grano entero cada semana; la frescura se nota desde que abres el paquete."</p>
                    <h6 class="fw-bold mb-0">— Sofía Ramírez</h6>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- SECCIÓN 7: NEWSLETTER Y HORARIOS -->
<section class="py-5">
    <div class="container">
        <div class="row align-items-center g-4 p-4 p-md-5 rounded-4 benefits-box" data-aos="fade-up">
            <div class="col-lg-7">
                <h3 class="font-serif fw-bold">Stay in the Loop</h3>
                <p class="text-secondary-coffee mb-0">Subscribe to get special offers, coffee tips and updates from Brew Haven.</p>
            </div>
            <div class="col-lg-5">
                <form action="index.php?action=gracias" method="GET" class="d-flex gap-2">
                    <input type="hidden" name="action" value="gracias">
                    <input type="hidden" name="cliente" value="Suscriptor VIP">
                    <input type="email" class="form-control bg-dark text-white border-secondary" placeholder="Enter your email" required>
                    <button type="submit" class="btn btn-gold px-4 hover-btn"><i class="fas fa-arrow-right"></i></button>
                </form>
            </div>
        </div>
    </div>
</section>

<?php include 'views/layout/footer.php'; ?>