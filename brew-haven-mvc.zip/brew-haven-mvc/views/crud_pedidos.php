<?php include 'views/layout/header.php'; ?>

<section class="py-5">
    <div class="container">
        <div class="row g-5">
            <!-- FORMULARIO POST (Crear / Editar) -->
            <div class="col-lg-5">
                <div class="card-coffee p-4 rounded-4 shadow">
                    <h3 class="font-serif text-gold mb-3">
                        <?= $pedidoEditar ? 'Editar Pedido #' . $pedidoEditar['id'] : 'Nuevo Pedido de Café' ?>
                    </h3>
                    <form action="index.php?action=guardar" method="POST">
                        <input type="hidden" name="id" value="<?= $pedidoEditar['id'] ?? '' ?>">

                        <div class="mb-3">
                            <label class="form-label">Selecciona tu Café</label>
                            <select name="producto_id" class="form-select bg-dark text-white border-secondary" required>
                                <?php foreach ($productos as $p): ?>
                                    <?php 
                                        $selected = '';
                                        if ($pedidoEditar && $pedidoEditar['producto_id'] == $p['id']) $selected = 'selected';
                                        elseif (isset($_GET['producto_id']) && $_GET['producto_id'] == $p['id']) $selected = 'selected';
                                    ?>
                                    <option value="<?= $p['id'] ?>" <?= $selected ?>>
                                        <?= htmlspecialchars($p['nombre']) ?> ($<?= number_format($p['precio'], 2) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Nombre Completo</label>
                            <input type="text" name="cliente_nombre" class="form-control bg-dark text-white border-secondary" 
                                   value="<?= htmlspecialchars($pedidoEditar['cliente_nombre'] ?? '') ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Correo Electrónico</label>
                            <input type="email" name="cliente_email" class="form-control bg-dark text-white border-secondary" 
                                   value="<?= htmlspecialchars($pedidoEditar['cliente_email'] ?? '') ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Cantidad</label>
                            <input type="number" name="cantidad" min="1" max="20" class="form-control bg-dark text-white border-secondary" 
                                   value="<?= htmlspecialchars($pedidoEditar['cantidad'] ?? 1) ?>" required>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Notas adicionales (Ej. Leche de almendras)</label>
                            <input type="text" name="notas" class="form-control bg-dark text-white border-secondary" 
                                   value="<?= htmlspecialchars($pedidoEditar['notas'] ?? '') ?>">
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-gold w-100 fw-bold hover-btn">
                                <i class="fas fa-save me-1"></i> <?= $pedidoEditar ? 'Actualizar Pedido' : 'Enviar Pedido' ?>
                            </button>
                            <?php if ($pedidoEditar): ?>
                                <a href="index.php?action=crud" class="btn btn-outline-light">Cancelar</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>

            <!-- TABLA DE REGISTROS (Lectura + Acciones GET para Editar/Eliminar) -->
            <div class="col-lg-7">
                <div class="card-coffee p-4 rounded-4 shadow">
                    <h3 class="font-serif text-gold mb-3">Pedidos Registrados en Base de Datos</h3>
                    <div class="table-responsive">
                        <table class="table table-dark table-hover align-middle">
                            <thead>
                                <tr class="text-gold">
                                    <th>#</th>
                                    <th>Cliente</th>
                                    <th>Café</th>
                                    <th>Cant.</th>
                                    <th>Total</th>
                                    <th>Acciones (GET)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($pedidos)): ?>
                                    <tr><td colspan="6" class="text-center text-secondary">Aún no hay pedidos registrados.</td></tr>
                                <?php else: ?>
                                    <?php foreach ($pedidos as $ped): ?>
                                    <tr>
                                        <td><?= $ped['id'] ?></td>
                                        <td>
                                            <strong><?= htmlspecialchars($ped['cliente_nombre']) ?></strong><br>
                                            <small class="text-secondary"><?= htmlspecialchars($ped['cliente_email']) ?></small>
                                        </td>
                                        <td><?= htmlspecialchars($ped['producto_nombre']) ?></td>
                                        <td><?= $ped['cantidad'] ?></td>
                                        <td class="text-gold fw-bold">$<?= number_format($ped['precio'] * $ped['cantidad'], 2) ?></td>
                                        <td>
                                            <!-- Enlace GET para Editar -->
                                            <a href="index.php?action=crud&edit=<?= $ped['id'] ?>" class="btn btn-sm btn-outline-warning me-1">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <!-- Enlace GET para Eliminar -->
                                            <a href="index.php?action=eliminar&id=<?= $ped['id'] ?>" 
                                               class="btn btn-sm btn-outline-danger"
                                               onclick="return confirm('¿Seguro que deseas eliminar este pedido?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'views/layout/footer.php'; ?>