<?php
require_once 'models/ProductoModel.php';

class HomeController {
    public function index() {
        $productoModel = new ProductoModel();
        $productos = $productoModel->obtenerTodos();
        require 'views/home.php';
    }
}